cd src/main/java/com/codingclubwebsite/codingclub/submission/CodeJudge/tempfiles/1de0d05c5e67c
g++ -lm code.cpp 2>err.txt