cd "src/main/java/com/codingclubwebsite/codingclub/submission/CodeJudge/tempfiles/1de0d05c5e67c"
chroot .
./a.out < in.txt > out.txt