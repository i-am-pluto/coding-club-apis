cd src/main/java/com/codingclubwebsite/codingclub/submission/CodeJudge/tempfiles/6e852428de9f7
g++ -lm code.cpp 2>err.txt