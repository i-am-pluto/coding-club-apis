package com.codingclubwebsite.codingclub.problem;

import org.springframework.data.repository.CrudRepository;

public interface ProblemRepository extends CrudRepository<Problem,String> {

}
