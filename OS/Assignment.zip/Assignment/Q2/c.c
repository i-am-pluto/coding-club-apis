#include <stdio.h>
#include <stdlib.h>
void C()
{
    printf("INSIDE FUNCTION C\n");
    exit(0);
}