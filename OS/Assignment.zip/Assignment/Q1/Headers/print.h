#ifndef PRINT_H
#define PRINT_H
#include "structs.h"
void printResult(Final *);
void printRecord(Student *, int);
#endif