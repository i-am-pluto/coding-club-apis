#ifndef COMPUTATION_H
#define COMPUTATION_H
#include "structs.h"

Student *makeRecords(char, int *);
Final *findRelevant(Student *, int);
#endif